/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hackathon.HackathonManagement.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author Infinity
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "TeamMemberName")
public class TeamMemberName {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @NotBlank(message = "Team member name is required")
    @Size(min = 2, max = 100, message = "Team member name must be between 2 and 100 characters")
    private String memberName;

    @NotBlank(message = "course name is required")
    @Size(min = 2, max = 100, message = "course name must be between 2 and 100 characters")
    private String course;
    
    @NotBlank(message = "city name is required")
    @Size(min = 2, max = 100, message = "city name must be between 2 and 100 characters")
    private String city;
    
    @NotBlank(message = "email name is required")
    @Size(min = 2, max = 100, message = "email must be between 2 and 100 characters")
    private String email ;
    
    @NotBlank(message = "status is required")
    @Size(min = 2, max = 100, message = "status must be between 2 and 100 characters")
    private String status;
    
    @ManyToOne
    @JoinColumn(name = "team_id")
    private Teams teams;

    @NotNull(message = "Joining time is required")
    private LocalDateTime timeDate;
}
