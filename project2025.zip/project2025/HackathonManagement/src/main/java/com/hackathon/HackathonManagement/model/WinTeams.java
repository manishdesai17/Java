/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hackathon.HackathonManagement.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author Infinity
 */
//this is win table
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WinTeams {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long win_id;
    private Long team_id;
}
