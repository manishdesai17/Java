/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hackathon.HackathonManagement.repository;

import com.hackathon.HackathonManagement.model.WinTeams;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Infinity
 */
//this is win tables repository

@Repository
public interface WinTeamRepository extends JpaRepository<WinTeams, Long> {

}
