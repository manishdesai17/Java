/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hackathon.HackathonManagement.service;

import com.hackathon.HackathonManagement.dto.MemberDto;
import com.hackathon.HackathonManagement.dto.TeamWithMembersDto;
import com.hackathon.HackathonManagement.model.Hackathons;
import com.hackathon.HackathonManagement.model.TeamMemberName;
import com.hackathon.HackathonManagement.model.Teams;
import com.hackathon.HackathonManagement.repository.HackathonRepository;
import com.hackathon.HackathonManagement.repository.TeamMemberNameRepository;
import com.hackathon.HackathonManagement.repository.TeamRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Infinity
 */
@Service
public class TeamServices {

    @Autowired
    private TeamRepository teamRepository;

    @Autowired
    private HackathonRepository hackathonRepository;

    public boolean addTeam(Teams teams, int hackathon_id) {
        Optional<Hackathons> team = this.hackathonRepository.findById(hackathon_id);
        if (team.isPresent()) {
            teams.setHackathon(team.get());

            if (teams.getTeamMemberName() != null) {
                for (TeamMemberName teamName : teams.getTeamMemberName()) {
                    teamName.setTeams(teams);
                }
            }
            this.teamRepository.save(teams);
            return true;
        }
        return false;
    }

//    get all teams
    public List<TeamWithMembersDto> getAllTeams() {
        return teamRepository.findAll().stream()
                .map(team -> new TeamWithMembersDto(
                team.getTeam_id(),
                team.getTeam_name(),
                team.getTeam_size(),
                team.getDriveLink(),
                team.getCollageUnivercityName(),
                team.getTeamMemberName().stream()
                        .map(member -> new MemberDto(
                        member.getMemberName(),
                        member.getCourse(),
                        member.getEmail(),
                        member.getStatus(),
                        member.getTimeDate()
                ))
                        .toList()
        )).toList();
    }

//    remove team
    public boolean removeTeams(Integer team_id) {
        Optional<Teams> teams = this.teamRepository.findById(team_id);
        if (teams.isPresent()) {
            this.teamRepository.deleteById(team_id);
            return true;
        }
        return false;
    }

    //for update team and teamMember both
    public boolean updateTeam(Teams teams, int hackathon_id) {
        Optional<Hackathons> team = this.hackathonRepository.findById(hackathon_id);
        if (team.isPresent()) {
            teams.setHackathon(team.get());

            if (teams.getTeamMemberName() != null) {
                for (TeamMemberName teamName : teams.getTeamMemberName()) {
                    teamName.setTeams(teams);
                }
            }
            this.teamRepository.save(teams);
            return true;
        }
        return false;
    }

//    this is admin can see team acording by hackathon 
    public List<TeamWithMembersDto> getTeamsByHackathonId(int hackathonId) {
        return teamRepository.findByHackathonId(hackathonId)
                .stream()
                .map(team -> new TeamWithMembersDto(
                team.getTeam_id(),
                team.getTeam_name(),
                team.getTeam_size(),
                team.getDriveLink(),
                team.getCollageUnivercityName(),
                team.getTeamMemberName().stream()
                        .map(member -> new MemberDto(
                        member.getMemberName(),
                        member.getCourse(),
                        member.getEmail(),
                        member.getStatus(),
                        member.getTimeDate()
                ))
                        .toList()
        ))
                .toList();
    }
}
