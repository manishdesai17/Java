package com.hackathon.HackathonManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HackathonManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
